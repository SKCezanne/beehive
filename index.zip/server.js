console.log("🔥 CORRECT SERVER FILE IS RUNNING 🔥");
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const nodemailer = require('nodemailer');

const { getPool, initDb } = require('./db');
const { writeEventsJson } = require('./storage');
const config = require('./config');

const app = express();

/* ---------------- BASIC MIDDLEWARE ---------------- */
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'super_secret_key_change_this',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // true only if using HTTPS
    httpOnly: true
  }
}));


/* ---------------- UPLOAD DIRECTORY ---------------- */
const uploadDir = path.join(__dirname, 'uploads');

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

app.use('/uploads', express.static(uploadDir));

/* ---------------- MULTER CONFIG ---------------- */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const uniqueName =
      Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, uniqueName + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files allowed'));
    }
  }
});

/* ---------------- NODEMAILER CONFIG ---------------- */
/*
  IMPORTANT:
  Replace with your actual Gmail + App Password
*/
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'cezanneshaik@gmail.com',
    pass: 'ohxhvwvyzrnxxlly'
  }
});


/* ---------------- HELPER: JSON SYNC ---------------- */
async function syncEventsToJson(events) {
  try {
    await writeEventsJson(events);
  } catch (err) {
    console.error('JSON sync failed:', err.message);
  }
}

/* ---------------- TEST SESSION ROUTE ---------------- */
app.get('/api/test-session', (req, res) => {
  if (!req.session.views) {
    req.session.views = 1;
  } else {
    req.session.views++;
  }
  res.json({ views: req.session.views });
});

/* ---------------- SESSION CHECK (am I logged in?) ---------------- */
app.get('/api/me', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ loggedIn: false });
  }
  res.json({ loggedIn: true, email: req.session.user.email });
});

/* ---------------- LOGOUT ---------------- */
app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ message: 'Logged out' });
  });
});

/* ---------------- SEND OTP ROUTE ---------------- */
app.post('/api/send-otp', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !email.endsWith('@srmist.edu.in')) {
      return res.status(400).json({ error: 'Invalid SRM email' });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    const pool = await getPool();

    await pool.query(
      `INSERT INTO email_verifications (email, otp, expires_at)
       VALUES (?, ?, ?)`,
      [email, otp, expiresAt]
    );

    await transporter.sendMail({
      from: 'Event Hive',
      to: email,
      subject: 'Event Hive Verification Code',
      text: `Your OTP is: ${otp}. It expires in 5 minutes.`
    });

    res.json({ message: 'OTP sent successfully' });

  } catch (err) {
    console.error('Send OTP error:', err);
    res.status(500).json({ error: 'Failed to send OTP' });
  }
});
app.post('/api/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP required' });
    }

    const pool = await getPool();

    const [rows] = await pool.query(
      `SELECT * FROM email_verifications
       WHERE email = ? AND otp = ?
       ORDER BY id DESC
       LIMIT 1`,
      [email, otp]
    );

    if (!rows.length) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    const record = rows[0];

    if (new Date(record.expires_at) < new Date()) {
      return res.status(400).json({ error: 'OTP expired' });
    }

    // Insert user if not exists
    await pool.query(
      `INSERT IGNORE INTO users (email, verified)
       VALUES (?, TRUE)`,
      [email]
    );

    // Create session
    req.session.user = {
      email
    };

    res.json({ message: 'Verified successfully' });

  } catch (err) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ error: 'Verification failed' });
  }
});
//-------------GET-----------------//
app.use(express.static(path.join(__dirname)));


/* ---------------- GET EVENTS ---------------- */
app.get('/api/events', async (req, res) => {
  
  try {
    const pool = await getPool();

    const [rows] = await pool.query(
  `SELECT id, name, description, category, price, time, image, registration_link
   FROM events
   ORDER BY time ASC`
);



 const events = rows.map(row => ({
  id: row.id,
  name: row.name,
  description: row.description,
  category: row.category,
  price: row.price,
  time: row.time
    ? new Date(row.time).toISOString().slice(0, 16)
    : null,
  image: row.image || null,
  registration_link: row.registration_link || null
}));


    await syncEventsToJson(events);

    res.json(events);

  } catch (err) {
    console.error('GET events error:', err);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

/* ---------------- CREATE EVENT ---------------- */
app.post('/api/events', upload.single('image'), async (req, res) => {
  if (!req.session.user) {
  return res.status(401).json({ error: 'Unauthorized' });
}

  try {
    const { name, description, category, price, time, registration_link } = req.body;


    if (!name || !description || !category || price == null || !time) {
      return res.status(400).json({
        error: 'Missing required fields'
      });
    }

    const pool = await getPool();

    let imagePath = null;
    if (req.file) {
      imagePath = `/uploads/${req.file.filename}`;
    }

    const formattedTime = time.replace('T', ' ').slice(0, 19);

    const createdBy = req.session.user ? req.session.user.email : null;

    const [result] = await pool.query(
      `INSERT INTO events (name, description, category, price, time, image, registration_link, created_by)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
  name,
  description,
  category,
  Number(price),
  formattedTime,
  imagePath,
  registration_link || null,
  createdBy
]

    );

    res.status(201).json({
      message: 'Event created successfully',
      id: result.insertId
    });

  } catch (err) {
    console.error('POST event error:', err);
    res.status(500).json({ error: 'Failed to register event' });
  }
});

/* ---------------- GET PROFILE ---------------- */
app.get('/api/profile', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT * FROM profiles WHERE email = ?', [req.session.user.email]);

    if (!rows.length) {
      return res.json({ email: req.session.user.email });
    }

    const p = rows[0];
    res.json({
      email: p.email,
      firstName: p.first_name,
      lastName: p.last_name,
      bio: p.bio,
      department: p.department,
      section: p.section,
      year: p.year,
      regNumber: p.reg_number,
      interests: p.interests || [],
      linkedin: p.linkedin,
      instagram: p.instagram,
      avatar: p.avatar
    });
  } catch (err) {
    console.error('GET profile error:', err);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

/* ---------------- SAVE PROFILE ---------------- */
app.post('/api/profile', upload.single('avatar'), async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const { firstName, lastName, bio, department, section, year, regNumber, linkedin, instagram, interests } = req.body;
    const email = req.session.user.email;

    let avatarPath = null;
    if (req.file) {
      avatarPath = `/uploads/${req.file.filename}`;
    }

    const pool = await getPool();

    // Check if profile exists
    const [existing] = await pool.query('SELECT id, avatar FROM profiles WHERE email = ?', [email]);

    let parsedInterests = [];
    try { parsedInterests = JSON.parse(interests || '[]'); } catch(e) {}

    if (existing.length) {
      // Update
      const updates = [
        'first_name = ?', 'last_name = ?', 'bio = ?', 'department = ?',
        'section = ?', 'year = ?', 'reg_number = ?', 'interests = ?',
        'linkedin = ?', 'instagram = ?'
      ];
      const values = [
        firstName || null, lastName || null, bio || null, department || null,
        section || null, year ? Number(year) : null, regNumber || null,
        JSON.stringify(parsedInterests), linkedin || null, instagram || null
      ];

      if (avatarPath) {
        updates.push('avatar = ?');
        values.push(avatarPath);
      }

      values.push(email);
      await pool.query(`UPDATE profiles SET ${updates.join(', ')} WHERE email = ?`, values);
    } else {
      // Insert
      await pool.query(
        `INSERT INTO profiles (email, first_name, last_name, bio, department, section, year, reg_number, interests, linkedin, instagram, avatar)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          email, firstName || null, lastName || null, bio || null,
          department || null, section || null, year ? Number(year) : null,
          regNumber || null, JSON.stringify(parsedInterests),
          linkedin || null, instagram || null, avatarPath
        ]
      );
    }

    res.json({ message: 'Profile saved' });
  } catch (err) {
    console.error('POST profile error:', err);
    res.status(500).json({ error: 'Failed to save profile' });
  }
});

/* ---------------- SINGLE EVENT DETAIL ---------------- */
app.get('/api/events/:id', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT id, name, description, category, price, time, image, registration_link, created_by
       FROM events WHERE id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Event not found' });
    const row = rows[0];
    res.json({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      price: row.price,
      time: row.time ? new Date(row.time).toISOString().slice(0, 16) : null,
      image: row.image || null,
      registration_link: row.registration_link || null,
      created_by: row.created_by || null
    });
  } catch (err) {
    console.error('GET event detail error:', err);
    res.status(500).json({ error: 'Failed to fetch event' });
  }
});

/* ---------------- CALENDAR: EVENTS FOR A MONTH ---------------- */
app.get('/api/calendar/:year/:month', async (req, res) => {
  try {
    const { year, month } = req.params;
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT id, name, description, category, price, time, image, registration_link
       FROM events
       WHERE YEAR(time) = ? AND MONTH(time) = ?
       ORDER BY time ASC`,
      [Number(year), Number(month)]
    );
    const events = rows.map(row => ({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      price: row.price,
      time: row.time ? new Date(row.time).toISOString().slice(0, 16) : null,
      image: row.image || null,
      registration_link: row.registration_link || null
    }));
    res.json(events);
  } catch (err) {
    console.error('GET calendar error:', err);
    res.status(500).json({ error: 'Failed to fetch calendar events' });
  }
});

/* ---------------- REGISTRATION COUNT PER EVENT ---------------- */
app.get('/api/events/:id/registrations', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT COUNT(*) AS count FROM registrations WHERE event_id = ?`,
      [req.params.id]
    );
    res.json({ event_id: Number(req.params.id), count: rows[0].count });
  } catch (err) {
    console.error('GET registration count error:', err);
    res.status(500).json({ error: 'Failed to fetch count' });
  }
});

/* ---------------- REGISTERED STUDENTS FOR AN EVENT (creator only) ---------------- */
app.get('/api/events/:id/students', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const eventId = req.params.id;

    // Verify the logged-in user is the event creator
    const [evRows] = await pool.query('SELECT created_by FROM events WHERE id = ?', [eventId]);
    if (!evRows.length) {
      return res.status(404).json({ error: 'Event not found' });
    }
    if (evRows[0].created_by !== req.session.user.email) {
      return res.status(403).json({ error: 'Only the event creator can view registered students' });
    }

    // Fetch all registered students with their details
    const [rows] = await pool.query(
      `SELECT r.email, r.first_name, r.last_name, r.department, r.year, r.section, r.reg_number, r.registered_at
       FROM registrations r
       WHERE r.event_id = ?
       ORDER BY r.registered_at ASC`,
      [eventId]
    );

    const students = rows.map(r => ({
      email: r.email,
      firstName: r.first_name,
      lastName: r.last_name,
      department: r.department,
      year: r.year,
      section: r.section,
      regNumber: r.reg_number,
      registeredAt: r.registered_at
    }));

    res.json({ event_id: Number(eventId), count: students.length, students });
  } catch (err) {
    console.error('GET event students error:', err);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

/* ---------------- MY REGISTERED EVENT IDS (quick check) ---------------- */
app.get('/api/my-registrations', async (req, res) => {
  if (!req.session.user) {
    return res.json({ ids: [] });
  }
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT event_id FROM registrations WHERE email = ?`,
      [req.session.user.email]
    );
    res.json({ ids: rows.map(r => r.event_id) });
  } catch (err) {
    console.error('GET my-registrations error:', err);
    res.status(500).json({ error: 'Failed to fetch registrations' });
  }
});

/* ---------------- PROFILE STATS (events posted + joined) ---------------- */
app.get('/api/profile/stats', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const email = req.session.user.email;

    const [[posted]] = await pool.query(
      `SELECT COUNT(*) AS count FROM events WHERE created_by = ?`,
      [email]
    );
    const [[joined]] = await pool.query(
      `SELECT COUNT(*) AS count FROM registrations WHERE email = ?`,
      [email]
    );

    res.json({
      eventsPosted: posted.count,
      eventsJoined: joined.count
    });
  } catch (err) {
    console.error('GET profile stats error:', err);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

/* ---------------- MY POSTED EVENTS ---------------- */
app.get('/api/my-events', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT e.id, e.name, e.description, e.category, e.price, e.time,
              e.image, e.registration_link, e.created_at,
              (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS registration_count
       FROM events e
       WHERE e.created_by = ?
       ORDER BY e.time ASC`,
      [req.session.user.email]
    );
    const events = rows.map(row => ({
      id: row.id,
      name: row.name,
      description: row.description,
      category: row.category,
      price: row.price,
      time: row.time ? new Date(row.time).toISOString().slice(0, 16) : null,
      image: row.image || null,
      registration_link: row.registration_link || null,
      created_at: row.created_at,
      registration_count: row.registration_count
    }));
    res.json(events);
  } catch (err) {
    console.error('GET my-events error:', err);
    res.status(500).json({ error: 'Failed to fetch your events' });
  }
});

/* ---------------- DELETE MY EVENT ---------------- */
app.delete('/api/events/:id', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const [result] = await pool.query(
      `DELETE FROM events WHERE id = ? AND created_by = ?`,
      [req.params.id, req.session.user.email]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Event not found or not yours' });
    }
    res.json({ message: 'Event deleted' });
  } catch (err) {
    console.error('DELETE event error:', err);
    res.status(500).json({ error: 'Failed to delete event' });
  }
});

/* ---------------- CART: GET REGISTERED EVENTS ---------------- */
app.get('/api/cart', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT e.id AS event_id, e.name, e.description, e.category, e.price, e.time,
              e.image, e.registration_link, r.registered_at
       FROM registrations r
       JOIN events e ON r.event_id = e.id
       WHERE r.email = ?
       ORDER BY e.time ASC`,
      [req.session.user.email]
    );

    const events = rows.map(row => ({
      event_id: row.event_id,
      name: row.name,
      description: row.description,
      category: row.category,
      price: row.price,
      time: row.time ? new Date(row.time).toISOString().slice(0, 16) : null,
      image: row.image || null,
      registration_link: row.registration_link || null,
      registered_at: row.registered_at
    }));

    res.json(events);
  } catch (err) {
    console.error('GET cart error:', err);
    res.status(500).json({ error: 'Failed to fetch cart' });
  }
});

/* ---------------- CART: ADD EVENT (saves student details) ---------------- */
app.post('/api/cart/:eventId', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    const email = req.session.user.email;

    // Pull student profile details to store with the registration
    let firstName = null, lastName = null, department = null, year = null, section = null, regNumber = null;
    const [profiles] = await pool.query('SELECT first_name, last_name, department, year, section, reg_number FROM profiles WHERE email = ?', [email]);
    if (profiles.length) {
      const p = profiles[0];
      firstName  = p.first_name;
      lastName   = p.last_name;
      department = p.department;
      year       = p.year;
      section    = p.section;
      regNumber  = p.reg_number;
    }

    await pool.query(
      `INSERT IGNORE INTO registrations (email, event_id, first_name, last_name, department, year, section, reg_number)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [email, req.params.eventId, firstName, lastName, department, year, section, regNumber]
    );
    res.json({ message: 'Registered successfully' });
  } catch (err) {
    console.error('POST cart error:', err);
    res.status(500).json({ error: 'Failed to register' });
  }
});

/* ---------------- CART: REMOVE EVENT ---------------- */
app.delete('/api/cart/:eventId', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not logged in' });
  }
  try {
    const pool = await getPool();
    await pool.query(
      `DELETE FROM registrations WHERE email = ? AND event_id = ?`,
      [req.session.user.email, req.params.eventId]
    );
    res.json({ message: 'Removed' });
  } catch (err) {
    console.error('DELETE cart error:', err);
    res.status(500).json({ error: 'Failed to remove' });
  }
});

/* ---------------- MULTER ERROR HANDLER ---------------- */
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Multer-specific error (file too large, unexpected field, etc.)
    return res.status(400).json({ error: err.message });
  }
  if (err) {
    console.error('Unhandled error:', err);
    return res.status(500).json({ error: err.message || 'Server error' });
  }
  next();
});

/* ---------------- SERVE FRONTEND ---------------- */
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

/* ---------------- START SERVER ---------------- */
async function start() {
  try {
    await initDb();

    app.listen(config.port, () => {
      console.log(`Event Hive running at http://localhost:${config.port}`);
    });

  } catch (err) {
    console.error('Startup error:', err);
    process.exit(1);
  }
}

start();
